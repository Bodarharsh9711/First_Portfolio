import React from 'react';
import { User, Cpu, GraduationCap, FolderGit2, Youtube, Mail } from 'lucide-react';

export type SectionId = 'about' | 'skills' | 'education' | 'projects' | 'experience' | 'contact';

interface PortfolioButtonProps {
  id: SectionId;
  label: string;
  side: 'left' | 'right';
  index: number;
  isActive: boolean;
  onClick: (id: SectionId) => void;
}

export const PortfolioButton: React.FC<PortfolioButtonProps> = ({
  id,
  label,
  side,
  index,
  isActive,
  onClick,
}) => {
  const getIcon = () => {
    switch (id) {
      case 'about':
        return <User className="w-3.5 h-3.5 flex-shrink-0" />;
      case 'skills':
        return <Cpu className="w-3.5 h-3.5 flex-shrink-0" />;
      case 'education':
        return <GraduationCap className="w-3.5 h-3.5 flex-shrink-0" />;
      case 'projects':
        return <FolderGit2 className="w-3.5 h-3.5 flex-shrink-0" />;
      case 'experience':
        return <Youtube className="w-3.5 h-3.5 flex-shrink-0" />;
      case 'contact':
        return <Mail className="w-3.5 h-3.5 flex-shrink-0" />;
    }
  };

  const hoverClass = side === 'left' ? 'retro-btn-left' : 'retro-btn-right';
  const numLabel = `0${index + 1}`;

  return (
    <button
      id={`btn-${id}`}
      type="button"
      aria-expanded={isActive}
      aria-controls={`card-${id}`}
      onClick={() => onClick(id)}
      className={`retro-btn ${hoverClass} ${
        isActive ? 'active' : ''
      } group w-full min-w-[140px] sm:w-[220px] md:w-[240px] xl:w-[260px] px-3.5 sm:px-4 py-3 sm:py-3.5 rounded-2xl border-[3px] border-[#101e29] font-silk text-[11px] sm:text-[12px] tracking-wider flex items-center justify-between gap-2 text-left cursor-pointer transition-all duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#101e29] select-none active:scale-[0.98] ${
        isActive
          ? 'bg-[#f7d66b] text-[#101e29] font-bold border-[#101e29] translate-y-[2px]'
          : 'bg-[#c5e1f2] hover:bg-[#daf0fc] text-[#101e29] hover:text-[#061017]'
      }`}
      style={{
        boxShadow: isActive
          ? '0 1px 0 #101e29, 0 2px 4px rgba(0,0,0,0.25)'
          : '0 5px 0 #101e29, 0 8px 16px rgba(15, 23, 42, 0.28)',
      }}
    >
      <div className="flex items-center gap-2.5 truncate">
        <span
          className={`p-1.5 rounded-lg border border-[#101e29]/30 flex-shrink-0 transition-colors ${
            isActive ? 'bg-[#101e29] text-[#f7d66b]' : 'bg-[#9fcbe2] text-[#101e29] group-hover:bg-[#8ebbda]'
          }`}
        >
          {getIcon()}
        </span>
        <div className="truncate flex flex-col">
          <span className="text-[8px] font-mono text-[#254257] font-semibold">
            {numLabel}
          </span>
          <span className="truncate uppercase font-bold text-[10px] sm:text-[11px] font-pixel tracking-wide leading-tight">
            {label}
          </span>
        </div>
      </div>

      {/* Retro indicator arrow */}
      <span
        aria-hidden="true"
        className={`text-[9px] font-pixel flex-shrink-0 transition-all ${
          isActive
            ? 'opacity-100 text-[#101e29] translate-x-0.5'
            : 'opacity-35 group-hover:opacity-100 text-[#101e29]'
        }`}
      >
        ▶
      </span>
    </button>
  );
};
