import React, { useState } from 'react';
import {
  X,
  ExternalLink,
  Copy,
  Check,
  Phone,
  Mail,
  Linkedin,
  Github,
  Award,
  BookOpen,
  Sparkles,
  Youtube,
  RotateCcw,
} from 'lucide-react';
import { SectionId } from './PortfolioButton';
import { PORTFOLIO_DATA } from '../config/portfolioData';

interface InfoCardProps {
  activeId: SectionId;
  side: 'left' | 'right';
  onClose: () => void;
}

export const InfoCard: React.FC<InfoCardProps> = ({ activeId, onClose }) => {
  const [copiedType, setCopiedType] = useState<'phone' | 'email' | null>(null);

  const handleCopy = async (text: string, type: 'phone' | 'email') => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
        setCopiedType(type);
        setTimeout(() => setCopiedType(null), 2000);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        setCopiedType(type);
        setTimeout(() => setCopiedType(null), 2000);
      }
    } catch {
      // Graceful fallback
    }
  };

  const animationClass = 'animate-modal-pop';

  const getSectionTitle = () => {
    switch (activeId) {
      case 'about':
        return 'About Me';
      case 'skills':
        return 'Skills & Expertise';
      case 'education':
        return 'Education & Honors';
      case 'projects':
        return 'Featured Projects';
      case 'experience':
        return 'Experience & Track Record';
      case 'contact':
        return 'Get In Touch';
    }
  };

  return (
    <aside
      id={`card-${activeId}`}
      role="region"
      aria-label={`${activeId} information panel`}
      className={`retro-card ${animationClass} w-full max-h-[85vh] overflow-y-auto retro-scrollbar bg-[#0f2334]/90 backdrop-blur-2xl border-2 border-[#5484a6]/60 shadow-[0_25px_60px_rgba(0,0,0,0.55),inset_0_1px_1px_rgba(255,255,255,0.2)] rounded-3xl p-5 sm:p-7 md:p-8 text-[#edf6fc] z-30 select-text`}
    >
      {/* Frosted Glass Header */}
      <div className="flex items-center justify-between border-b-2 border-[#5484a6]/30 pb-3 sm:pb-4 mb-4 sm:mb-5 select-none">
        <div
          className="flex items-center gap-2.5 cursor-pointer group"
          onClick={onClose}
          title="Click to dismiss card & change emoji"
        >
          <span className="w-3 h-3 bg-[#f7d66b] border border-[#101e29] inline-block group-hover:scale-125 transition-transform shadow-xs" />
          <h2 className="font-pixel text-[12px] sm:text-[14px] md:text-[15px] tracking-wider uppercase text-[#f7d66b] font-bold group-hover:text-[#ffea85] transition-colors drop-shadow-xs">
            {getSectionTitle()}
          </h2>
          <span className="text-[10px] font-pixel text-[#8ab4d3] opacity-70 group-hover:opacity-100 transition-opacity">
            [↺]
          </span>
        </div>

        <button
          onClick={onClose}
          type="button"
          aria-label="Close dialog and change emoji"
          className="p-1.5 sm:p-2 rounded-xl bg-[#1b394f]/80 hover:bg-[#254f6e] text-[#f7d66b] border border-[#5484a6]/50 transition-all active:scale-90 cursor-pointer shadow-sm"
          title="Close card & change emoji"
        >
          <X className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>
      </div>

      {/* Helpful Hint Bar */}
      <div
        onClick={onClose}
        className="text-[9px] sm:text-[10px] font-mono text-[#a2cbef] mb-4 text-center bg-[#183952]/60 hover:bg-[#1d4462] py-1.5 px-3 rounded-xl border border-[#5484a6]/30 cursor-pointer transition-colors select-none"
        title="Click here to close card & change emoji"
      >
        CLICK CARD TO CLOSE & CHANGE EMOJI REACTION ↺
      </div>

      {/* Card Body by Section */}
      <div className="space-y-4 sm:space-y-5 text-sm">
        {/* 1. ABOUT ME */}
        {activeId === 'about' && (
          <div className="space-y-4">
            <div className="bg-[#18364e]/70 backdrop-blur-md border border-[#48789b]/40 rounded-2xl p-4 sm:p-5">
              <div className="font-silk text-base sm:text-lg md:text-xl font-bold text-[#f7d66b] tracking-wide">
                {PORTFOLIO_DATA.personal.name}
              </div>
              <div className="text-xs sm:text-sm font-semibold text-[#cbe4f7] mt-1">
                {PORTFOLIO_DATA.personal.role}
              </div>
              <div className="text-[11px] sm:text-xs text-[#8cb6d5] font-mono mt-0.5">
                {PORTFOLIO_DATA.personal.university}
              </div>
            </div>

            <div className="bg-[#153046]/70 backdrop-blur-md border border-[#48789b]/35 rounded-2xl p-4 sm:p-5 text-xs sm:text-sm leading-relaxed text-[#dbeffc]">
              "{PORTFOLIO_DATA.personal.intro}"
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <a
                href={PORTFOLIO_DATA.personal.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between px-4 py-3 bg-[#1d3d57]/80 hover:bg-[#254d6e] border border-[#5484a6]/50 rounded-2xl font-silk text-xs text-[#edf6fc] transition-all font-bold group shadow-sm hover:translate-y-[-1px]"
              >
                <div className="flex items-center gap-2.5">
                  <Github className="w-4 h-4 text-[#f7d66b]" />
                  <span>GitHub Profile</span>
                </div>
                <ExternalLink className="w-3.5 h-3.5 text-[#a1cbe9] group-hover:text-[#f7d66b] transition-colors" />
              </a>

              <a
                href={PORTFOLIO_DATA.personal.linkedinUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between px-4 py-3 bg-[#1d3d57]/80 hover:bg-[#254d6e] border border-[#5484a6]/50 rounded-2xl font-silk text-xs text-[#edf6fc] transition-all font-bold group shadow-sm hover:translate-y-[-1px]"
              >
                <div className="flex items-center gap-2.5">
                  <Linkedin className="w-4 h-4 text-[#38bdf8]" />
                  <span>LinkedIn Profile</span>
                </div>
                <ExternalLink className="w-3.5 h-3.5 text-[#a1cbe9] group-hover:text-[#38bdf8] transition-colors" />
              </a>
            </div>
          </div>
        )}

        {/* 2. SKILLS */}
        {activeId === 'skills' && (
          <div className="space-y-4">
            <div>
              <div className="font-pixel text-[10px] sm:text-[11px] uppercase tracking-wider text-[#f7d66b] mb-2.5 flex items-center gap-2 font-bold">
                <span className="w-2 h-2 bg-[#f7d66b] inline-block border border-[#101e29]" />
                Technical & Creative Tools
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {PORTFOLIO_DATA.skills.technical.map((tool) => (
                  <div
                    key={tool}
                    className="flex items-center gap-2 bg-[#17354d]/75 backdrop-blur-sm border border-[#48789b]/35 rounded-xl px-3 py-2 text-xs sm:text-[13px] font-medium text-[#edf6fc]"
                  >
                    <span className="text-[#f7d66b] font-pixel text-[8px]">▪</span>
                    <span className="truncate">{tool}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <div className="font-pixel text-[10px] sm:text-[11px] uppercase tracking-wider text-[#f7d66b] mb-2 flex items-center gap-2 font-bold">
                <span className="w-2 h-2 bg-[#f7d66b] inline-block border border-[#101e29]" />
                Core Competencies
              </div>
              <div className="flex flex-wrap gap-2">
                {PORTFOLIO_DATA.skills.competencies.map((comp) => (
                  <span
                    key={comp}
                    className="px-3 py-1.5 bg-[#17354d]/75 backdrop-blur-sm border border-[#48789b]/40 rounded-xl text-xs font-silk font-bold text-[#d8effe]"
                  >
                    {comp}
                  </span>
                ))}
              </div>
            </div>

            <div>
              <div className="font-pixel text-[10px] sm:text-[11px] uppercase tracking-wider text-[#f7d66b] mb-2 flex items-center gap-2 font-bold">
                <span className="w-2 h-2 bg-[#f7d66b] inline-block border border-[#101e29]" />
                Languages Known
              </div>
              <div className="text-xs sm:text-sm text-[#cce4f7] font-mono bg-[#17354d]/75 backdrop-blur-sm border border-[#48789b]/35 rounded-xl px-3.5 py-2">
                {PORTFOLIO_DATA.skills.languages.join('  ·  ')}
              </div>
            </div>
          </div>
        )}

        {/* 3. EDUCATION */}
        {activeId === 'education' && (
          <div className="space-y-4">
            <div className="space-y-3">
              {PORTFOLIO_DATA.education.map((edu, idx) => (
                <div
                  key={idx}
                  className="bg-[#17354d]/75 backdrop-blur-md border border-[#48789b]/40 rounded-2xl p-4 sm:p-5 space-y-1.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-silk text-xs sm:text-sm font-bold text-[#f7d66b]">
                      {edu.institution}
                    </span>
                    <span className="text-[10px] font-mono text-[#bae0fa] bg-[#1d4361] px-2 py-0.5 rounded-md border border-[#5484a6]/40">
                      {edu.location}
                    </span>
                  </div>
                  <div className="text-xs sm:text-[13px] font-medium text-[#edf6fc] leading-snug">
                    {edu.degree}
                  </div>
                  <div className="text-[11px] text-[#93bddc] font-mono">
                    Status: <span className="font-semibold text-[#a7f3d0]">{edu.status}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Academic Achievement from CV */}
            <div className="bg-[#fef08a]/15 border-2 border-[#fde047]/60 rounded-2xl p-4 sm:p-5 space-y-1.5 backdrop-blur-sm">
              <div className="font-pixel text-[10px] sm:text-[11px] text-[#fef08a] flex items-center gap-2 font-bold uppercase tracking-wider">
                <Award className="w-4 h-4 text-[#facc15]" />
                {PORTFOLIO_DATA.achievement.title}
              </div>
              <div className="text-xs sm:text-[13px] leading-relaxed text-[#fef9c3] font-medium">
                {PORTFOLIO_DATA.achievement.detail}
              </div>
            </div>

            {/* Certifications Sub-block */}
            <div>
              <div className="font-pixel text-[10px] sm:text-[11px] uppercase tracking-wider text-[#f7d66b] mb-2 flex items-center gap-2 font-bold">
                <BookOpen className="w-4 h-4 text-[#f7d66b]" />
                Certificates & Verified Courses
              </div>
              <ul className="space-y-2 text-xs sm:text-[13px]">
                {PORTFOLIO_DATA.certificates.map((cert, idx) => (
                  <li
                    key={idx}
                    className="p-2.5 sm:p-3 bg-[#17354d]/75 border border-[#48789b]/35 rounded-xl leading-snug text-[#edf6fc] flex items-center gap-2.5"
                  >
                    <span className="text-[#f7d66b] font-pixel text-[8px]">▪</span>
                    <span>{cert.title}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {/* 4. PROJECTS */}
        {activeId === 'projects' && (
          <div className="space-y-4">
            <div className="text-xs sm:text-sm text-[#cbe3f7]">
              Explore developer projects, repositories, and open source work:
            </div>

            <div className="space-y-3">
              {PORTFOLIO_DATA.projects.map((proj) => (
                <div
                  key={proj.name}
                  className="bg-[#17354d]/75 backdrop-blur-md border border-[#48789b]/40 rounded-2xl p-4 sm:p-5 space-y-2 hover:border-[#f7d66b]/60 transition-colors"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-silk text-xs sm:text-sm font-bold text-[#f7d66b] truncate">
                      {proj.name}
                    </span>
                    <a
                      href={proj.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 rounded-lg bg-[#1f4463] hover:bg-[#28577e] text-[#edf6fc] border border-[#5484a6]/40 transition-colors"
                      title={`Open ${proj.name} on GitHub`}
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                  <p className="text-xs sm:text-[13px] text-[#d6ecfa] leading-relaxed">
                    {proj.description}
                  </p>
                </div>
              ))}
            </div>

            <a
              href={PORTFOLIO_DATA.personal.githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 flex items-center justify-center gap-2.5 w-full py-3 bg-[#f7d66b] hover:bg-[#ebd060] border-2 border-[#101e29] rounded-2xl font-silk text-xs text-[#101e29] font-bold transition-all shadow-md active:translate-y-0.5"
            >
              <Github className="w-4 h-4" />
              <span>View Full GitHub Profile</span>
              <ExternalLink className="w-4 h-4 opacity-80" />
            </a>
          </div>
        )}

        {/* 5. EXPERIENCE */}
        {activeId === 'experience' && (
          <div className="space-y-4">
            <div className="bg-[#17354d]/75 backdrop-blur-md border border-[#48789b]/40 rounded-2xl p-4 sm:p-5 space-y-2">
              <div className="flex items-center gap-2.5 text-[#f7d66b]">
                <Youtube className="w-5 h-5 text-red-500" />
                <span className="font-silk text-xs sm:text-sm font-bold">
                  {PORTFOLIO_DATA.experience.title}
                </span>
              </div>
              <div className="text-[11px] sm:text-xs font-mono text-[#98c2e0]">
                Duration: <span className="font-semibold text-[#a7f3d0]">{PORTFOLIO_DATA.experience.duration}</span>
              </div>
              <p className="text-xs sm:text-[13px] text-[#dbeffc] leading-relaxed pt-1">
                "{PORTFOLIO_DATA.experience.description}"
              </p>
            </div>

            {/* Department 1st Rank Highlight */}
            <div className="bg-[#fef08a]/15 border-2 border-[#fde047]/60 rounded-2xl p-4 sm:p-5 space-y-1.5 backdrop-blur-sm">
              <div className="font-pixel text-[10px] sm:text-[11px] text-[#fef08a] flex items-center gap-2 font-bold uppercase tracking-wider">
                <Sparkles className="w-4 h-4 text-[#facc15]" />
                Top FOET Department Honors
              </div>
              <div className="text-xs sm:text-[13px] text-[#fef9c3] leading-relaxed font-medium">
                {PORTFOLIO_DATA.achievement.detail}
              </div>
            </div>

            {/* Certified Training */}
            <div>
              <div className="font-pixel text-[10px] sm:text-[11px] uppercase tracking-wider text-[#f7d66b] mb-2 flex items-center gap-2 font-bold">
                <Award className="w-4 h-4 text-[#f7d66b]" />
                Certified Training
              </div>
              <ul className="space-y-1.5 text-xs sm:text-[13px]">
                {PORTFOLIO_DATA.certificates.map((cert, idx) => (
                  <li
                    key={idx}
                    className="p-2.5 bg-[#17354d]/75 border border-[#48789b]/35 rounded-xl text-[#edf6fc]"
                  >
                    {cert.title}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {/* 6. CONTACT ME */}
        {activeId === 'contact' && (
          <div className="space-y-3.5">
            {/* Phone */}
            <div className="bg-[#17354d]/75 backdrop-blur-md border border-[#48789b]/40 rounded-2xl p-3.5 sm:p-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 truncate">
                <Phone className="w-5 h-5 text-[#f7d66b] flex-shrink-0" />
                <div className="truncate">
                  <div className="text-[10px] font-pixel text-[#89b4d4] uppercase font-bold">Phone Number</div>
                  <a
                    href={PORTFOLIO_DATA.personal.phoneCall}
                    className="text-xs sm:text-sm font-mono font-bold text-[#edf6fc] hover:text-[#f7d66b] transition-colors"
                  >
                    {PORTFOLIO_DATA.personal.phone}
                  </a>
                </div>
              </div>
              <button
                type="button"
                onClick={() => handleCopy(PORTFOLIO_DATA.personal.phone, 'phone')}
                className="p-2 rounded-xl bg-[#1f4463] hover:bg-[#28577e] text-[#f7d66b] border border-[#5484a6]/40 transition-transform active:scale-90 flex-shrink-0"
                title="Copy phone number"
                aria-label="Copy phone number"
              >
                {copiedType === 'phone' ? (
                  <Check className="w-4 h-4 text-emerald-400 font-bold" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </button>
            </div>

            {/* Email */}
            <div className="bg-[#17354d]/75 backdrop-blur-md border border-[#48789b]/40 rounded-2xl p-3.5 sm:p-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 truncate">
                <Mail className="w-5 h-5 text-[#f7d66b] flex-shrink-0" />
                <div className="truncate">
                  <div className="text-[10px] font-pixel text-[#89b4d4] uppercase font-bold">Email Address</div>
                  <a
                    href={PORTFOLIO_DATA.personal.emailMailto}
                    className="text-xs sm:text-sm font-mono font-bold text-[#edf6fc] hover:text-[#f7d66b] transition-colors truncate block"
                  >
                    {PORTFOLIO_DATA.personal.email}
                  </a>
                </div>
              </div>
              <button
                type="button"
                onClick={() => handleCopy(PORTFOLIO_DATA.personal.email, 'email')}
                className="p-2 rounded-xl bg-[#1f4463] hover:bg-[#28577e] text-[#f7d66b] border border-[#5484a6]/40 transition-transform active:scale-90 flex-shrink-0"
                title="Copy email address"
                aria-label="Copy email address"
              >
                {copiedType === 'email' ? (
                  <Check className="w-4 h-4 text-emerald-400 font-bold" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </button>
            </div>

            {/* Social Links */}
            <div className="pt-1 grid grid-cols-2 gap-3">
              <a
                href={PORTFOLIO_DATA.personal.linkedinUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-3 px-3 bg-[#1d3d57]/80 hover:bg-[#254d6e] border border-[#5484a6]/50 rounded-2xl font-silk text-xs font-bold text-[#edf6fc] transition-colors shadow-sm"
              >
                <Linkedin className="w-4 h-4 text-[#38bdf8]" />
                <span>LinkedIn</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-70" />
              </a>

              <a
                href={PORTFOLIO_DATA.personal.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-3 px-3 bg-[#1d3d57]/80 hover:bg-[#254d6e] border border-[#5484a6]/50 rounded-2xl font-silk text-xs font-bold text-[#edf6fc] transition-colors shadow-sm"
              >
                <Github className="w-4 h-4 text-[#f7d66b]" />
                <span>GitHub</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-70" />
              </a>
            </div>
          </div>
        )}
      </div>

      {/* Retro 2.5D Dismiss & Change Emoji Action Button */}
      <div className="pt-4 select-none border-t border-[#5484a6]/30 mt-4 sm:mt-5">
        <button
          type="button"
          onClick={onClose}
          className="w-full py-3 px-4 bg-[#f7d66b] hover:bg-[#ebd060] text-[#101e29] font-pixel text-[10px] sm:text-[11px] font-bold border-2 border-[#101e29] rounded-2xl flex items-center justify-center gap-2.5 cursor-pointer shadow-md active:translate-y-0.5 transition-all"
          title="Dismiss card and trigger next emoji reaction"
        >
          <RotateCcw className="w-4 h-4 text-[#101e29]" />
          <span>CLOSE & CHANGE EMOJI REACTION ↺</span>
        </button>
      </div>
    </aside>
  );
};
