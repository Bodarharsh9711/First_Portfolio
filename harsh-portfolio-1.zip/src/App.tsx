import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Volume2, VolumeX, Sparkles, Smile, RotateCcw } from 'lucide-react';
import { PortfolioButton, SectionId } from './components/PortfolioButton';
import { InfoCard } from './components/InfoCard';
import { PORTFOLIO_DATA } from './config/portfolioData';

// Initial smiley emoji timestamp (stationary smiling face)
const DEFAULT_SMILE_TIME = 0.9;

interface SectionConfig {
  id: SectionId;
  label: string;
  side: 'left' | 'right';
  targetTime: number; // Exact timestamp in seconds where emoji pose settles
  emojiName: string;
}

const SECTIONS: SectionConfig[] = [
  { id: 'about', label: 'ABOUT ME', side: 'left', targetTime: 1.8, emojiName: 'Curious Halo' },
  { id: 'skills', label: 'SKILLS', side: 'left', targetTime: 3.3, emojiName: 'Focused Tech' },
  { id: 'education', label: 'EDUCATION', side: 'left', targetTime: 4.6, emojiName: 'Studious Scholar' },
  { id: 'projects', label: 'PROJECTS', side: 'right', targetTime: 6.0, emojiName: 'Creative Builder' },
  { id: 'experience', label: 'EXPERIENCE', side: 'right', targetTime: 7.6, emojiName: 'Digital Creator' },
  { id: 'contact', label: 'CONTACT ME', side: 'right', targetTime: 9.0, emojiName: 'Friendly Connect' },
];

export default function App() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [activeCard, setActiveCard] = useState<SectionId | null>(null);
  const [activeSide, setActiveSide] = useState<'left' | 'right'>('left');
  const [isMuted, setIsMuted] = useState(true);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [currentEmojiName, setCurrentEmojiName] = useState('Happy Smiley');

  // Animation frame ref for frame-perfect timestamp stopping
  const rafRef = useRef<number | null>(null);
  const targetTimeRef = useRef<number>(DEFAULT_SMILE_TIME);

  const leftButtons = SECTIONS.filter((s) => s.side === 'left');
  const rightButtons = SECTIONS.filter((s) => s.side === 'right');

  // Cancel any ongoing frame monitoring
  const cancelTransitionMonitoring = useCallback(() => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
  }, []);

  // Smooth forward video transition to a target timestamp.
  // The video starts playing, smoothly moves forward until reaching the target emoji reaction,
  // and then immediately PAUSES/STOPS at that reaction.
  const transitionToTime = useCallback(
    (targetTime: number, emojiLabel?: string) => {
      const video = videoRef.current;
      if (!video) return;

      cancelTransitionMonitoring();
      targetTimeRef.current = targetTime;
      setIsTransitioning(true);

      const currentTime = video.currentTime;
      // If target time is behind current time, we loop forward through the 10s video cycle
      const isWrapAround = targetTime <= currentTime;

      video.muted = isMuted;
      video.loop = true; // Ensure video can wrap around if needed
      video.playbackRate = 1.0;
      video.play().catch(() => {});

      let hasWrapped = !isWrapAround;
      let prevTime = currentTime;
      const startTimeMs = performance.now();

      const checkTime = () => {
        const vid = videoRef.current;
        if (!vid) return;

        const curr = vid.currentTime;

        // If wrapping around: detect loop wrap when currentTime resets or drops
        if (!hasWrapped) {
          if (curr < prevTime || curr >= 9.85 || curr < 0.25) {
            hasWrapped = true;
          }
          prevTime = curr;
        }

        if (hasWrapped) {
          // Check if reached or passed the target timestamp
          if (curr >= targetTime) {
            vid.pause();
            vid.currentTime = targetTime;
            setIsTransitioning(false);
            if (emojiLabel) {
              setCurrentEmojiName(emojiLabel);
            }
            return;
          }
        }

        // Safety fallback: if 12s elapsed, safely pause at target
        if (performance.now() - startTimeMs > 12000) {
          vid.pause();
          vid.currentTime = targetTime;
          setIsTransitioning(false);
          if (emojiLabel) {
            setCurrentEmojiName(emojiLabel);
          }
          return;
        }

        rafRef.current = requestAnimationFrame(checkTime);
      };

      rafRef.current = requestAnimationFrame(checkTime);
    },
    [cancelTransitionMonitoring, isMuted]
  );

  // Initial load: Stop video on the bright smiley emoji (0.9s) immediately.
  // Video is paused and stationary until user clicks!
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    video.defaultMuted = true;
    video.muted = isMuted;
    video.playsInline = true;

    const setInitialSmiley = () => {
      video.currentTime = DEFAULT_SMILE_TIME;
      video.pause();
      setCurrentEmojiName('Happy Smiley');
    };

    if (video.readyState >= 2) {
      setInitialSmiley();
    } else {
      video.addEventListener('loadeddata', setInitialSmiley, { once: true });
    }

    return () => {
      video.removeEventListener('loadeddata', setInitialSmiley);
      cancelTransitionMonitoring();
    };
  }, [cancelTransitionMonitoring, isMuted]);

  // Dynamic mute update
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.muted = isMuted;
    }
  }, [isMuted]);

  // Advance to the next emoji reaction in sequence and stop
  const handleNextEmoji = useCallback(() => {
    const currentIndex = activeCard ? SECTIONS.findIndex((s) => s.id === activeCard) : -1;
    const nextIndex = (currentIndex + 1) % SECTIONS.length;
    const nextSection = SECTIONS[nextIndex];
    transitionToTime(nextSection.targetTime, nextSection.emojiName);
  }, [activeCard, transitionToTime]);

  // Card Dismissal Handler:
  // When user clicks the card, close button, or active button again:
  // The card disappears AND the video starts, smoothly changes to the next emoji reaction, and stops!
  const handleCardDismissAndChangeEmoji = useCallback(() => {
    if (!activeCard) {
      handleNextEmoji();
      return;
    }

    const currentIndex = SECTIONS.findIndex((s) => s.id === activeCard);
    setActiveCard(null);

    if (currentIndex >= 0) {
      // Advance to the next emoji reaction in sequence
      const nextIndex = (currentIndex + 1) % SECTIONS.length;
      const nextSection = SECTIONS[nextIndex];
      transitionToTime(nextSection.targetTime, nextSection.emojiName);
    } else {
      transitionToTime(DEFAULT_SMILE_TIME, 'Happy Smiley');
    }
  }, [activeCard, handleNextEmoji, transitionToTime]);

  // Handle Button Click:
  // 1. If user clicks active button again -> Card disappears AND changes emoji!
  // 2. If user clicks a new button -> Card opens and video transitions to that emoji reaction, then stops!
  const handleButtonClick = (id: SectionId) => {
    const section = SECTIONS.find((s) => s.id === id);
    if (!section) return;

    if (activeCard === id) {
      // User clicked active button again: Card disappears & changes emoji!
      handleCardDismissAndChangeEmoji();
    } else {
      // New button selected: Open card & transition video forward to that emoji reaction, then stop!
      setActiveCard(id);
      setActiveSide(section.side);
      transitionToTime(section.targetTime, section.emojiName);
    }
  };

  // Reset to initial smiley emoji
  const handleResetToSmiley = () => {
    setActiveCard(null);
    transitionToTime(DEFAULT_SMILE_TIME, 'Happy Smiley');
  };

  // Keyboard accessibility: Escape key closes card & changes emoji
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && activeCard !== null) {
        handleCardDismissAndChangeEmoji();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeCard, handleCardDismissAndChangeEmoji]);

  return (
    <div className="relative w-screen h-screen min-h-screen bg-[#8aabc0] overflow-x-hidden overflow-y-auto lg:overflow-hidden flex flex-col justify-between select-none">
      {/* Decorative Retro Sparkles matching visual direction */}
      <div className="absolute left-8 top-12 pointer-events-none animate-star-twinkle opacity-60 hidden md:block">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path
            d="M12 0 C12 6 6 12 0 12 C6 12 12 18 12 24 C12 18 18 12 24 12 C18 12 12 6 12 0 Z"
            fill="#dbeafe"
          />
        </svg>
      </div>

      <div className="absolute right-10 bottom-10 pointer-events-none animate-star-twinkle opacity-75 hidden sm:block">
        <svg width="38" height="38" viewBox="0 0 38 38" fill="none">
          <path
            d="M19 0 C19 10 10 19 0 19 C10 19 19 28 19 38 C19 28 28 19 38 19 C28 19 19 10 19 0 Z"
            fill="#e0f2fe"
          />
        </svg>
      </div>

      {/* TOP HEADER: Darker Retro Blue Bar as requested */}
      <header className="relative z-20 w-full px-4 sm:px-6 py-2.5 sm:py-3 flex items-center justify-between border-b-[3px] border-[#101e29] bg-[#1d3547] text-[#edf6fc] shadow-md">
        <div className="flex items-center gap-2.5">
          <span className="w-2.5 h-2.5 bg-[#f7d66b] border border-[#101e29] inline-block shadow-xs" />
          <h1 className="font-pixel text-[10px] sm:text-[12px] md:text-[13px] text-[#f0f7fc] font-bold tracking-wider uppercase drop-shadow-xs">
            {PORTFOLIO_DATA.personal.name}
          </h1>
          <span className="hidden sm:inline-block text-[#a5c9df] font-silk text-[10px]">
            · IT STUDENT & CREATOR
          </span>
        </div>

        {/* Action Controls: Transition Status + Cycle Next Emoji + Smiley Reset + Audio Toggle */}
        <div className="flex items-center gap-2">
          {/* Transition indicator */}
          {isTransitioning && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#f7d66b] border-2 border-[#101e29] text-[9px] font-pixel text-[#101e29] font-bold animate-pulse shadow-xs">
              <Sparkles className="w-3 h-3 text-[#101e29]" />
              <span className="hidden xs:inline">CHANGING EMOJI...</span>
            </div>
          )}

          {/* Change / Next Emoji button */}
          <button
            type="button"
            onClick={handleNextEmoji}
            className="retro-btn px-2.5 py-1.5 rounded-lg border-2 border-[#101e29] bg-[#2a4d66] hover:bg-[#345d7b] text-[#edf6fc] flex items-center gap-1.5 text-[9px] sm:text-[10px] font-silk font-bold cursor-pointer transition-all active:scale-95 shadow-sm"
            title="Cycle forward to next emoji reaction"
            aria-label="Cycle forward to next emoji reaction"
          >
            <RotateCcw className="w-3.5 h-3.5 text-[#f7d66b]" />
            <span className="hidden xs:inline">NEXT EMOJI</span>
          </button>

          {/* Reset to Smiley button */}
          <button
            type="button"
            onClick={handleResetToSmiley}
            className="retro-btn px-2.5 py-1.5 rounded-lg border-2 border-[#101e29] bg-[#2a4d66] hover:bg-[#345d7b] text-[#edf6fc] flex items-center gap-1.5 text-[9px] sm:text-[10px] font-silk font-bold cursor-pointer transition-all active:scale-95 shadow-sm"
            title="Reset to starting smiley emoji"
            aria-label="Reset to starting smiley emoji"
          >
            <Smile className="w-3.5 h-3.5 text-[#f7d66b]" />
            <span className="hidden xs:inline">SMILEY</span>
          </button>

          {/* Audio Toggle */}
          <button
            type="button"
            onClick={() => setIsMuted(!isMuted)}
            className="retro-btn px-2.5 py-1.5 rounded-lg border-2 border-[#101e29] bg-[#2a4d66] hover:bg-[#345d7b] text-[#edf6fc] flex items-center gap-1 text-[9px] sm:text-[10px] font-silk font-bold cursor-pointer transition-all active:scale-95 shadow-sm"
            title={isMuted ? 'Unmute video audio' : 'Mute video audio'}
            aria-label={isMuted ? 'Unmute audio' : 'Mute audio'}
          >
            {isMuted ? (
              <>
                <VolumeX className="w-3.5 h-3.5 text-[#f0f7fc]" />
                <span className="hidden xs:inline">MUTE</span>
              </>
            ) : (
              <>
                <Volume2 className="w-3.5 h-3.5 text-[#a7f3d0]" />
                <span className="hidden xs:inline">AUDIO ON</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* MAIN VIEWPORT REGION: Symmetrical 3-Column Layout with Zoomed Center Emoji */}
      <main className="relative flex-1 w-full max-w-[1600px] mx-auto px-4 sm:px-8 py-3 flex flex-col lg:flex-row items-center justify-between gap-4 lg:gap-8 min-h-0">
        {/* Subtle Atmospheric Telemetry Markers */}
        <div className="absolute left-6 top-3 text-[8px] font-mono text-[#254257] opacity-60 hidden xl:block select-none pointer-events-none">
          SYS // HARSH_OS_v2.6 [ONLINE 🟢]
        </div>
        <div className="absolute right-6 top-3 text-[8px] font-mono text-[#254257] opacity-60 hidden xl:block select-none pointer-events-none">
          CHAR // HARSH BODAR · IT DEV
        </div>
        <div className="absolute left-6 bottom-3 text-[8px] font-mono text-[#254257] opacity-60 hidden xl:block select-none pointer-events-none">
          FPS: 60 · PIXEL ART CANVAS
        </div>
        <div className="absolute right-6 bottom-3 text-[8px] font-mono text-[#254257] opacity-60 hidden xl:block select-none pointer-events-none">
          LOC // GUJARAT, INDIA 📍
        </div>

        {/* ========================================================== */}
        {/* LEFT COLUMN: 3 Profile Buttons (Symmetrical & Spaced)      */}
        {/* ========================================================== */}
        <div className="w-full lg:w-[260px] xl:w-[280px] 2xl:w-[310px] flex flex-col items-center lg:items-start z-20 order-2 lg:order-1">
          {/* Header Tag */}
          <div className="hidden lg:flex items-center gap-1.5 mb-3 text-[9px] font-pixel text-[#162937] font-bold tracking-wider select-none">
            <span className="w-2 h-2 bg-[#f7d66b] border border-[#101e29] inline-block shadow-xs" />
            <span>PROFILE MATRIX</span>
          </div>

          {/* Left Buttons Stack */}
          <div className="flex flex-row flex-wrap lg:flex-col gap-3 sm:gap-4 w-full justify-center lg:justify-start">
            {leftButtons.map((btn, idx) => (
              <PortfolioButton
                key={btn.id}
                id={btn.id}
                label={btn.label}
                side="left"
                index={idx}
                isActive={activeCard === btn.id}
                onClick={handleButtonClick}
              />
            ))}
          </div>
        </div>

        {/* ========================================================== */}
        {/* CENTER REGION: Large Animated Emoji Video (Pure & Clean)   */}
        {/* ========================================================== */}
        <div className="relative flex-1 w-full max-w-[420px] sm:max-w-[520px] md:max-w-[600px] lg:max-w-[680px] xl:max-w-[760px] 2xl:max-w-[820px] flex items-center justify-center z-10 order-1 lg:order-2 my-auto">
          {/* Video Container: Full unclipped details, natural 16:9 aspect, no collapse */}
          <div
            onClick={handleNextEmoji}
            className="relative w-full aspect-video flex items-center justify-center cursor-pointer select-none"
            title="Click emoji character to trigger next reaction animation"
          >
            <video
              ref={videoRef}
              src="/video/emoji.mp4"
              playsInline
              preload="auto"
              className="w-full h-full object-contain block select-none pointer-events-none"
              aria-label="Harsh Bodar Animated Emoji"
            >
              <source src="/video/emoji.mp4" type="video/mp4" />
              <source src="/video/emoji-animation.mp4" type="video/mp4" />
              <source src="/emoji.mp4" type="video/mp4" />
            </video>
          </div>
        </div>

        {/* ========================================================== */}
        {/* RIGHT COLUMN: 3 Portfolio Buttons (Symmetrical & Spaced)   */}
        {/* ========================================================== */}
        <div className="w-full lg:w-[260px] xl:w-[280px] 2xl:w-[310px] flex flex-col items-center lg:items-end z-20 order-3">
          {/* Header Tag */}
          <div className="hidden lg:flex items-center justify-end gap-1.5 mb-3 text-[9px] font-pixel text-[#162937] font-bold tracking-wider select-none">
            <span>PORTFOLIO HUB</span>
            <span className="w-2 h-2 bg-[#f7d66b] border border-[#101e29] inline-block shadow-xs" />
          </div>

          {/* Right Buttons Stack */}
          <div className="flex flex-row flex-wrap lg:flex-col gap-3 sm:gap-4 w-full justify-center lg:justify-end">
            {rightButtons.map((btn, idx) => (
              <PortfolioButton
                key={btn.id}
                id={btn.id}
                label={btn.label}
                side="right"
                index={idx + 3}
                isActive={activeCard === btn.id}
                onClick={handleButtonClick}
              />
            ))}
          </div>
        </div>
      </main>

      {/* ========================================================== */}
      {/* FLOATING RETRO INFO CARD DIALOGUE MODAL                    */}
      {/* ========================================================== */}
      {activeCard && (
        <div
          role="dialog"
          aria-modal="true"
          onClick={handleCardDismissAndChangeEmoji}
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-[#08131d]/60 backdrop-blur-md transition-all"
        >
          {/* Big Glass Card Container */}
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-[560px] sm:max-w-[640px] md:max-w-[720px]"
          >
            <InfoCard
              activeId={activeCard}
              side={activeSide}
              onClose={handleCardDismissAndChangeEmoji}
            />
          </div>
        </div>
      )}

      {/* DOWN BAR: Darker Retro Blue Footer as requested */}
      <footer className="relative z-20 w-full px-5 py-2.5 flex items-center justify-between border-t-[3px] border-[#101e29] bg-[#1d3547] text-[9px] sm:text-[10px] font-silk text-[#edf6fc] shadow-md">
        <div className="flex items-center gap-2 text-[#d6ecfa]">
          <Sparkles className="w-3 h-3 text-[#f7d66b]" />
          <span>
            {isTransitioning ? (
              <span className="text-[#f7d66b] font-bold">TRANSITIONING...</span>
            ) : (
              <span>EMOJI: <strong className="text-[#f7d66b]">{currentEmojiName.toUpperCase()}</strong> (STOPPED)</span>
            )}
          </span>
        </div>
        <div className="text-[#a5c9df] font-mono text-[9px]">
          {isTransitioning ? (
            <span className="font-bold text-[#f7d66b]">▶ TRANSITIONING TO REACTION EMOJI...</span>
          ) : activeCard ? (
            <span className="font-bold text-[#f7d66b]">CLICK CARD / BUTTON AGAIN TO CLOSE & CHANGE EMOJI ↺</span>
          ) : (
            <span>CLICK ANY BUTTON TO START VIDEO & STOP AT REACTION EMOJI</span>
          )}
        </div>
      </footer>
    </div>
  );
}
