export interface ProjectItem {
  name: string;
  description: string;
  url: string;
  isMainProfile?: boolean;
}

export interface EducationItem {
  institution: string;
  location: string;
  degree: string;
  status: string;
}

export interface CertificateItem {
  title: string;
}

export const PORTFOLIO_DATA = {
  personal: {
    name: 'Harsh Bodar',
    role: 'B.Tech Information Technology Student',
    university: 'Atmiya University, Rajkot',
    intro:
      'I am an aspiring IT professional and a student who enjoys learning new technologies and preparing for the future. I am looking for opportunities to grow, contribute, and build a strong career.',
    githubUrl: 'https://github.com/Bodarharsh9711',
    linkedinUrl: 'https://linkedin.com/in/harsh-bodar-93a596336/',
    phone: '+91 9512840531',
    phoneCall: 'tel:+919512840531',
    email: 'nptelharshbodar10@gmail.com',
    emailMailto: 'mailto:nptelharshbodar10@gmail.com',
  },

  skills: {
    technical: [
      'CapCut',
      'VN Editor',
      'Canva',
      'AI tools for content creation, images, videos, and visual content',
    ],
    competencies: ['Time management', 'Leadership', 'Teamwork'],
    languages: ['English', 'Gujarati', 'Hindi'],
  },

  education: [
    {
      institution: 'Atmiya University',
      location: 'Rajkot',
      degree: 'Bachelor of Technology (B.Tech) in Information Technology',
      status: 'Currently pursuing',
    },
    {
      institution: 'Vidhya Guru Science',
      location: 'Amreli',
      degree: 'Higher Secondary Certificate (HSC)',
      status: 'Completed',
    },
  ] as EducationItem[],

  projects: [
    {
      name: 'WebSite',
      description: 'Official portfolio and web showcase repository.',
      url: 'https://github.com/Bodarharsh9711/WebSite',
    },
    {
      name: 'website_for_one_of_the_most_useful.',
      description: 'Event platform repository for starter community activities.',
      url: 'https://github.com/Bodarharsh9711/website_for_one_of_the_most_useful.',
    },
  ] as ProjectItem[],

  experience: {
    title: 'YouTube Channel Experience',
    duration: 'Approximately 1.5 years',
    description:
      'Experience working on a YouTube channel, with an interest in content creation and digital visuals.',
  },

  achievement: {
    title: 'Academic Excellence',
    detail: 'Secured 1st Rank in the 4th Semester across the Entire FOET Department.',
  },

  certificates: [
    { title: 'Python for Library Data Analytics and Automation' },
    { title: 'Python with AI at Tops Technology' },
    { title: 'Viksit Bharat Young Leaders Dialogue 2027' },
  ] as CertificateItem[],
};
